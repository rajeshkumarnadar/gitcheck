<?php

$data = array(
    array(
        'id' => 'dasharath',
        'parentId' => null,
        'childId' => 'Ram'
    ),
    array(
        'id' => 'Ram',
        'parentId' => 'dasharath',
        'childId' => 'Ram'
    ),
    array(
        'id' => 'laxman',
        'parentId' => 'dasharath',
        'childId' => 'laxman'
    ),
    array(
        'id' => 'bharat',
        'parentId' => 'dasharath',
        'childId' => 'bharat'
    ),
    array(
        'id' => 'shatrugan',
        'parentId' => 'dasharath',
        'childId' => 'shatrugan'
    ),
    array(
        'id' => 'Luv',
        'parentId' => 'Ram',
        'childId' => 'Luv'
    ),
    array(
        'id' => 'kush',
        'parentId' => 'Ram',
        'childId' => 'kush'
    ),
);

$GLOBALS=0;
function buildTree( $ar, $pid = null ) {
    $op = array();
	

    foreach( $ar as $item ) {
    	$GLOBALS++;
        if( $item['parentId'] == $pid ) {         
            $op[$item['id']] = array(

            );

            // using recursion
            $children =  buildTree( $ar, $item['id'] );
            if( $children ) {
                $op[$item['id']]['children'] = $children;
            }
        }
    }
echo $GLOBALS.'<br />';
    return $op;
}
echo $GLOBALS.'<br />';
$tree=json_encode( buildTree( $data ) );
echo $tree;

echo array_search('dasharath',$data);



?>