<?php
error_reporting(-1);
$order_date="2015-11-25";
$day_delivery="wednesday";
$day_deliv_digt=get_day_digit($day_delivery);
$order_day=date(N,strtotime($order_date));
//echo $day_delivery."</br>";
//echo $order_date;

$events=getFmessage_date($order_date,$day_deliv_digt,$order_day);

//print_r(json_encode($events));

function getFmessage_date($od_date,$day_del_digt,$order_day){
	$day_diff=$day_del_digt-$order_day;
	$date1=0;
	$date2=0;
	$date3=0;
	$date4=0;

	if($day_diff>3){
		$date4=$day_diff;
		$date3=$day_diff-1;
	}else if($day_diff<0){
		$day_diff=7+$day_diff;
		$date4=$day_diff;
		$date3=$day_diff-1;
	}else if($day_diff>=0 && $day_diff<=3){
		$day_diff=7+$day_diff;
		$date4=$day_diff;
		$date3=$day_diff-1;			
	}

	$date1=1;	
	$delivery_date=date('Y-m-d', strtotime('+'.$date4.' days', strtotime($od_date)));		
	$date11 = new DateTime($delivery_date);
	$date2 = new DateTime($od_date);
	$interval = $date11->diff($date2);
	$date2=  round($interval->days/2);

	$arr_date1=date('Y-m-d', strtotime('+'.$date1.' days', strtotime($od_date)));
	$arr_date2=date('Y-m-d', strtotime('+'.$date2.' days', strtotime($od_date)));
	$arr_date3=date('Y-m-d', strtotime('+'.$date3.' days', strtotime($od_date)));
	$arr_date4=date('Y-m-d', strtotime('+'.$date4.' days', strtotime($od_date)));

	/*echo "</br>Msg 1 :". date('jS F Y ,l', strtotime('+'.$date1.' days', strtotime($od_date)))."</br>";
	echo "Msg 2 :". date('jS F Y ,l', strtotime('+'.$date2.' days', strtotime($od_date)))."</br>";
	echo "Msg 3 :". date('jS F Y ,l', strtotime('+'.$date3.' days', strtotime($od_date)))."</br>";
	echo "Delivery Date :". date('jS F Y ,l', strtotime('+'.$date4.' days', strtotime($od_date)))."</br>";
	echo "Week 1 Magzine Delivery Date :". date('jS F Y ,l', strtotime('+'.$date4.' days', strtotime($od_date)))."</br>";*/

	$magdate=date('Y-m-d', strtotime('+'.$date4.' days', strtotime($od_date)));
	$magdays=0;
	
	
	$event=array();
	$title=array('order date','Msg 1','Msg 2','Msg 3','Delivery Date','Week 1 Magzine Delivery Date');
	$start=array($od_date,$arr_date1,$arr_date2,$arr_date3,$arr_date4,$arr_date4);
	$color=array('purple','red','blue','green','green','green');


	for ($i=0; $i <count($title) ; $i++) { 
		$arrvar=array('title'=>$title[$i],'start'=>$start[$i],'color'=>$color[$i]);
		//print_r($arrvar);
		array_push($event,$arrvar);
	}


	for ($i=1; $i <48 ; $i++) { 
		$magdays=$magdays+7;
		$title1="Week ".(1+$i)." Msg 1 Magzine  Date ";
		$start1=date('Y-m-d', strtotime('+'.($magdays-3).' days', strtotime($magdate)));
		$color="red";
		$arrvar=array('title'=>$title1,'start'=>$start1,'color'=>$color);
		array_push($event,$arrvar);

		$title1="Week ".(1+$i)." Msg 2 Magzine  Date ";
		$start1=date('Y-m-d', strtotime('+'.($magdays-2).' days', strtotime($magdate)));
		$color="#25acea";
		$arrvar=array('title'=>$title1,'start'=>$start1,'color'=>$color);
		array_push($event,$arrvar);

		$title1="Week ".(1+$i)." Msg 3 Magzine  Date ";
		$start1=date('Y-m-d', strtotime('+'.($magdays-1).' days', strtotime($magdate)));
		$color="#00ffb2";
		$arrvar=array('title'=>$title1,'start'=>$start1,'color'=>$color);
		array_push($event,$arrvar);


		$title1="Week ".(1+$i)." Magzine Delivery Date ";
		$start1=date('Y-m-d', strtotime('+'.$magdays.' days', strtotime($magdate)));
		$color="green";
		$arrvar=array('title'=>$title1,'start'=>$start1,'color'=>$color);
		array_push($event,$arrvar);

		//array_push($start,$start1);

		//echo "Week ".(1+$i)." Magzine Delivery Date ". date('jS F Y ,l', strtotime('+'.$magdays.' days', strtotime($magdate)))."</br>";
	}

	return $event;
}




function get_day_digit($day){

	switch(strtolower($day)){
    case "monday":
		return 1;
        break;
    case "tuesday":
        return 2;
        break;
    case "wednesday":
        return 3;
        break;
    case "thursday":
        return 4;
        break;
    case "friday":
        return 5;
        break;
    case "saturday":
        return 6;
        break;
    case "sunday":
        return 7;
        break;
    default:
        return "Invalid day.";
        break;
}

	
}

?>




<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8' />
<link href='fullcalendar.css' rel='stylesheet' />
<link href='fullcalendar.print.css' rel='stylesheet' media='print' />
<script src='lib/moment.min.js'></script>
<script src='lib/jquery.min.js'></script>
<script src='fullcalendar.min.js'></script>
<script>

	$(document).ready(function() {
		
		$('#calendar').fullCalendar({
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,agendaWeek,agendaDay'
			},
			defaultDate: '<?php echo $order_date;?>',
			editable: true,
			eventLimit: true, // allow "more" link when too many events
			events: <?php echo json_encode($events); ?>,

		});
		
	});

</script>
<style>

	body {
		margin: 40px 10px;
		padding: 0;
		font-family: "Lucida Grande",Helvetica,Arial,Verdana,sans-serif;
		font-size: 14px;
	}

	#calendar {
		max-width: 900px;
		margin: 0 auto;
	}

</style>
</head>
<body>

	<div id='calendar'></div>

</body>
</html>
