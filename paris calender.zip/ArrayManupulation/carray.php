<?php

$data = array(
    array(       
        'parentId' => 'nikhil',
        'childId' => 'sanket'
    ),
    array(
        'parentId' => 'sanket',
        'childId' => 'amrit'
    ),
    array(
        'parentId' => 'sanket',
        'childId' => 'amol'
    ),
    array(
        'parentId' => 'ashish',
        'childId' => 'rajesh'
    ),
    array(
        'parentId' => 'ashish',
        'childId' => 'nirmala'
    ),
    array(
        'parentId' => 'nikhil',
        'childId' => 'ashish'
    ),
     array(
        'parentId' => 'nikhil',
        'childId' => 'dharmendra'
    )
);



    $op = array();
    $child="";
    $parent="";



    foreach( $data as $dat ) {    	 
		$parent=$dat['parentId'];
		foreach ($data as $chil) {
		 	if ($parent==$chil['parentId']) {
		 		$child=$child.','.$chil['childId'];    	 	}
		}   	
    }
    
  


?>